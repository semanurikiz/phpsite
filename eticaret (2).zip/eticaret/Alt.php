<!-- Footer section -->
<section class="footer-section">
	<div class="container">
		<div class="footer-logo text-center">
		<a href="index.php"><img src="Çiçek Buketi (3).png" alt="" style="width: 20%; height: auto;"></a>

		</div>
		<div class="row">
			<div class="col-lg-3 col-sm-6">
				<div class="footer-widget about-widget">
					<h2>hakkımızda</h2>
					<p>En güzel çiçekleri sitemizde bulabilirsiniz. Sizin için  özel paketleme yapıyoruz.</p>
					<img src="img/cards.png" alt="">
				</div>
			</div>
			<div class="col-lg-3 col-sm-6">
				
			</div>
			<div class="col-lg-3 col-sm-6">
				
			</div>
			<div class="col-lg-3 col-sm-6">
				<div class="footer-widget contact-widget">
					<h2>İLETİŞİM</h2>
					<div class="con-info">
						<span>Şirketimiz</span>
						<p>Çiçek Buketi </p>
					</div>
					<div class="con-info">
						<span>Adres</span>
						<p>Gökyüzü, sema cd. No:05 Odunpazarı,Eskişehir </p>
					</div>
					<div class="con-info">
						<span>Telefon</span>
						<p>+90 0552 023 5645</p>
					</div>
					<div class="con-info">
						<span>E-Mail</span>
						<p>cicekbuketi@gmail.com</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="social-links-warp">
		<div class="container">
			<div class="social-links">
				<a href="<?php echo $Ayar['ayar_instagram'] ?>" class="instagram"><i class="fa fa-instagram"></i><span>instagram</span></a>
				<a href="<?php echo $Ayar['ayar_facebook'] ?>" class="facebook"><i class="fa fa-facebook"></i><span>facebook</span></a>
				<a href="<?php echo $Ayar['ayar_twitter'] ?>" class="twitter"><i class="fa fa-twitter"></i><span>twitter</span></a>
	
			</div>

			<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --> 
			<p class="text-white text-center mt-5"> &copy;<script>document.write(new Date().getFullYear());</script>Çiçek Buketi.Tüm Hakları Saklıdır.<i class="fa fa-heart-o" aria-hidden="true"></i></p>
			<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->

		</div>
	</div>
</section>
<!-- Footer section end -->



<!--====== Javascripts & Jquery ======-->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.slicknav.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.nicescroll.min.js"></script>
<script src="js/jquery.zoom.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/main.js"></script>

</body>
</html>
