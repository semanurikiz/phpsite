<?php 
include "baglan.php";
include "fonksiyon.php";
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title><?php echo $Ayar['ayar_baslik'] ?></title>
	<meta charset="UTF-8">
	<meta name="description" content="<?php echo $Ayar['ayar_aciklama'] ?>">
	<meta name="keywords" content="<?php echo $Ayar['ayar_kelime'] ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->
	<link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Google Font -->
	<link href="https://fonts.googleapis.com/css?family=Josefin+Sans:300,300i,400,400i,700,700i" rel="stylesheet">


	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/flaticon.css"/>
	<link rel="stylesheet" href="css/slicknav.min.css"/>
	<link rel="stylesheet" href="css/jquery-ui.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="css/animate.css"/>
	<link rel="stylesheet" href="css/style.css"/>
<style>
	.image-container {
  display: flex;
  justify-content: space-around;
  align-items: center;
  margin-top: 20px;
}

.image-item {
  text-align: center;
  margin: 0 10px;
}

.image-item img {
  width: 300px;  /* Make sure all images have the same width */
  height: 300px; /* Fix the height to match the width */
  object-fit: cover;  /* Ensure the images fill the area without distortion */
  border-radius: 8px;
  transition: transform 0.3s, box-shadow 0.3s;
}

/* Box shadow for Image 1 */
.image-item .img1 {
  box-shadow: 0px 4px 8px rgba(255, 0, 0, 0.5); /* Red tone shadow */
}

.image-item .img1:hover {
  transform: scale(1.05);
  box-shadow: 0px 8px 16px rgba(255, 0, 0, 0.7); /* Hover: stronger red shadow */
}

/* Box shadow for Image 2 */
.image-item .img2 {
  box-shadow: 0px 4px 8px rgba(176, 86, 255, 0.5); /* Purple tone shadow */
}

.image-item .img2:hover {
  transform: scale(1.05);
  box-shadow: 0px 8px 16px rgba(176, 86, 255, 0.7); /* Hover: stronger purple shadow */
}

/* Box shadow for Image 3 */
.image-item .img3 {
  box-shadow: 0px 4px 8px rgba(244, 122, 255, 0.81); /* Blue tone shadow */
}

.image-item .img3:hover {
  transform: scale(1.05);
  box-shadow: 0px 8px 16px rgba(244, 122, 255, 0.81); /* Hover: stronger blue shadow */
}

.image-item h3 {
  margin-top: 10px;
  font-size: 18px;
  color: #333;
}
.feature-inner {
    display: flex;
    align-items: center; /* Center vertically */
}

.feature-icon {
    margin-top: 10px; /* Move image down */
}

.shipping-icon {
    width: 100px;
    height: auto;
    margin-right: 15px;
}

h2 {
    margin-top: 10px; /* Move the text down */
    font-size: 20px; /* Adjust text size if needed */
}
.small-image {
    width: 50px; /* İstediğiniz genişlik */
    height: auto; /* Oranını korur */
}

</style>
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

	<!-- Header section -->
	<header class="header-section">
		<div class="header-top">
			<div class="container">
				<div class="row">
					<div class="col-lg-2 text-center text-lg-left">
						<!-- logo -->
						<a href="./index.html" class="logo">
						<img src="çiçekbuket.png" alt="" style="width: 100px; height: auto; margin-top: 5px; ">

						</a>
					</div>
					<div class="col-xl-6 col-lg-5">
						<form class="header-search-form">
							<input type="text" placeholder="Çiçek Buketinde Arayın ....">
							<button><i class="flaticon-search"></i></button>
						</form>
					</div>
					<div class="col-xl-4 col-lg-5">
						<div class="user-panel">
							<div class="up-item">
								<i class="flaticon-profile"></i>
								<a href="login.php">Giriş</a> Yap yada <a href="sign in.php">Kayıt Ol</a>
							</div>
							<div class="up-item">
								<div class="shopping-card">
									<i class="flaticon-bag"></i>
									<span>0</span>
								</div>
								<a href="#">Shopping Cart</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<nav class="main-navbar">
			<div class="container">
				<!-- menu -->
				<ul class="main-menu">
					<li><a href="index.php">Anasayfa</a></li>
					<li><a href="urunler.php">Ürünler</a></li>
					<li><a href="cicekbilgi.php">Çiçekler Hakkında bilgi</a></li>
					
				</ul>
			</div>
		</nav>
		<div class="image-container">
    <div class="image-item">
      <img class="img1" src="gül (2).png" alt="Gül">
      <h3>Gül Çiçeği</h3>
    </div>
    <div class="image-item">
      <img class="img2" src="lavanta.png" alt="Lavanta">
      <h3>Lavanta Çiçeği</h3>
    </div>
    <div class="image-item">
      <img class="img3" src="lale.jpg" alt="Lale">
      <h3>Lale Çiçeği</h3>
    </div>
		
	</header>
	<!-- Header section end -->
