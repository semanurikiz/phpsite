<?php 
include "Ust.php";
?>


<section class="product-filter-section">
	<div class="container">
		<div class="section-title">
			<h2>ÜRÜNLERİMİZ</h2>
		</div>
		<div class="row">
			<?php 
			$Urunler=$db->query("SELECT * FROM urun WHERE urun_vitrin=2 ORDER BY RAND() LIMIT 50");

			while($Urun=$Urunler->fetch())
			{
				?>
				<div class="col-lg-3 col-sm-6">
					<?php UrunListeGorunumu($Urun) ?>
				</div>
				<?php 
			}
			?>
		</div>
	
	</div>
</section>

<?php 
include "Alt.php";
?>