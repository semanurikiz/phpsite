<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: girisyap.php");
    exit;
}
   
?>


<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Çiçek Buketi Admin Paneli</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            color: #333;
        }

        .navbar {
            background-color: rgb(161, 114, 183);
            color: white;
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            flex-direction: column;
            padding: 20px;
        }

        .navbar-header {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 40px;
        }

        .navbar-header img {
            width: 80px;
            height: auto;
            margin-bottom: 15px;
            border-radius: 50%;
        }

        .navbar-header h1 {
            font-size: 20px;
            margin: 0;
            font-weight: bold;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            padding: 12px 15px;
            font-weight: 500;
            margin: 5px 0;
            border-radius: 5px;
            transition: background-color 0.1s ease, transform 0.3s ease;
            display: flex;
            align-items: center;
        }

        .navbar a:hover {
            background-color:rgb(100, 44, 120);
            transform: translateX(5px);
        }

        .navbar a i {
            margin-right: 10px;
        }

        .content {
            margin-left: 270px;
            padding: 40px;
            flex: 1;
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .dashboard {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            gap: 20px;
            margin-top: 20px;
        }

        .stat-box {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 20px;
            width: 23%;
            min-width: 200px;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .stat-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .stat-box h3 {
            font-size: 18px;
            color: #343a40;
            margin-bottom: 15px;
        }

        .stat-box p {
            font-size: 16px;
            color: #6c757d;
        }

        .table {
            width: 100%;
            margin-top: 30px;
            border-collapse: collapse;
        }

        .table th, .table td {
            border: 1px solid #dee2e6;
            padding: 12px;
            text-align: left;
            font-size: 14px;
            color: #495057;
        }

        .table th {
            background-color: rgb(36, 64, 99);
            color: white;
        }

        .footer {
            background-color: #343a40;
            color: white;
            text-align: center;
            padding: 15px 0;
        }
        
    </style>
</head>
<body>
    <div class="navbar">
        <div class="navbar-header">
            <img src="cicek.png" alt="">
            <h1>Çiçek Buketi</h1>
        </div>
        <a href="anasayfa.php"><i>🏡</i> Ana Sayfa</a>
<a href="setting.php"><i>🔧</i> Ayarlar</a>
<a href="urunler.php"><i>📦</i> Ürün Yönetimi</a>
<a href="logout.php"><i>❌</i> Çıkış Yap</a>

    </div>  

    <div class="footer">
        © 2024 Çiçek Buketi.Tüm Hakları Saklıdır.
    </div>
</body>
</html>